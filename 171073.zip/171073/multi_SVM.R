setwd("C:/Users/20593368/Desktop/171073")
require(rgdal)
require(raster)
require(caret)
###multi_SVM.R
source("loader.R")
set.seed(42)
data.ratio <- 1
data <- mat[sample(nrow(mat), nrow(mat)*data.ratio),]


training_x <- data[, obsValues]
training_y <- data[, classValues]

ctrl <- trainControl (method="none")
tuneGrid <- expand.grid(sigma=0.4, C=32)
svm.fit <- train(x = training_x,
                 y = training_y,
                 method = "svmRadial", 
                 trControl = ctrl,
                 tuneGrid = tuneGrid
)

print(svm.fit)

####YEAR 1

source("multi_loader.R")
new.data <- new.mat[sample(nrow(new.mat),nrow(new.mat)*data.ratio),]
new.test_x <- new.data[ ,obsValues]
new.test_y <- new.data[ ,classValues]

svm.predict <- predict(svm.fit, newdata = new.test_x)
cf1 <- confusionMatrix(svm.predict , new.test_y)
##This is the one that has worked
cf1 <- table(svm.predict , new.test_y)

print(cf1)



# predict the final image and output it to a file
method_name <- "SVM"
method_name_parsed <- gsub ('([[:punct:]])|\\s+','_', method_name)
filename1 <- paste(outputFolder, "/multi_",method_name_parsed,
                   imageDate,"TRAIN",imageDate.new,"TEST",sep="")

finaling <- predict(xvars, svm.fit, type="raw",
                    index=1, na.rm=TRUE, progress="text")
levels(finaling)

writeRaster(finaling, filename=filename1, format="GTiff", overwrite=TRUE)



###YEAR 2

source("multi_loader.R")
new.data1 <- new.mat1[sample(nrow(new.mat1),nrow(new.mat1)*data.ratio),]
new.test_x1 <- new.data1[ ,obsValues]
new.test_y1 <- new.data1[ ,classValues]

svm.predict1 <- predict(svm.fit, newdata1 = new.test_x1)
cf11 <- confusionMatrix(svm.predict1 , new.test_y1)
##This is the one that has worked
cf11 <- table(svm.predict1 , new.test_y1)

print(cf11)



# predict the final image and output it to a file
method_name1 <- "SVM"
method_name_parsed1 <- gsub ('([[:punct:]])|\\s+','_', method_name1)
filename11 <- paste(outputFolder, "/multi_",method_name_parsed1,
                    imageDate,"TRAIN",imageDate.new1,"TEST",sep="")

finaling1 <- predict(xvars1, svm.fit, type="raw",
                     index=1, na.rm=TRUE, progress="text")
levels(finaling1)

writeRaster(finaling1, filename=filename11, format="GTiff", overwrite=TRUE)



###YEAR 3

source("multi_loader.R")
new.data2 <- new.mat2[sample(nrow(new.mat2),nrow(new.mat2)*data.ratio),]
new.test_x2 <- new.data2[ ,obsValues]
new.test_y2 <- new.data2[ ,classValues]

svm.predict2 <- predict(svm.fit, newdata2 = new.test_x2)
cf12 <- confusionMatrix(svm.predict2 , new.test_y2)
##This is the one that has worked
cf12 <- table(svm.predict2 , new.test_y2)

print(cf12)



# predict the final image and output it to a file
method_name2 <- "SVM"
method_name_parsed2 <- gsub ('([[:punct:]])|\\s+','_', method_name2)
filename12 <- paste(outputFolder, "/multi_",method_name_parsed2,
                    imageDate,"TRAIN",imageDate.new2,"TEST",sep="")

finaling2 <- predict(xvars2, svm.fit, type="raw",
                     index=1, na.rm=TRUE, progress="text")
levels(finaling2)

writeRaster(finaling2, filename=filename12, format="GTiff", overwrite=TRUE)


###YEAR 4

source("multi_loader.R")
new.data3 <- new.mat3[sample(nrow(new.mat3),nrow(new.mat3)*data.ratio),]
new.test_x3 <- new.data3[ ,obsValues]
new.test_y3 <- new.data3[ ,classValues]

svm.predict3 <- predict(svm.fit, newdata3 = new.test_x3)
cf13 <- confusionMatrix(svm.predict3 , new.test_y3)
##This is the one that has worked
cf13 <- table(svm.predict3 , new.test_y3)

print(cf13)



# predict the final image and output it to a file
method_name3 <- "SVM"
method_name_parsed3 <- gsub ('([[:punct:]])|\\s+','_', method_name3)
filename13 <- paste(outputFolder, "/multi_",method_name_parsed3,
                    imageDate,"TRAIN",imageDate.new3,"TEST",sep="")

finaling3 <- predict(xvars3, svm.fit, type="raw",
                     index=1, na.rm=TRUE, progress="text")
levels(finaling3)

writeRaster(finaling3, filename=filename13, format="GTiff", overwrite=TRUE)




###YEAR 5

source("multi_loader.R")
new.data4 <- new.mat4[sample(nrow(new.mat4),nrow(new.mat4)*data.ratio),]
new.test_x4 <- new.data4[ ,obsValues]
new.test_y4 <- new.data4[ ,classValues]

svm.predict4 <- predict(svm.fit, newdata4 = new.test_x4)
cf14 <- confusionMatrix(svm.predict4 , new.test_y4)
##This is the one that has worked
cf14 <- table(svm.predict4 , new.test_y4)

print(cf14)



# predict the final image and output it to a file
method_name4 <- "SVM"
method_name_parsed4 <- gsub ('([[:punct:]])|\\s+','_', method_name4)
filename14 <- paste(outputFolder, "/multi_",method_name_parsed4,
                    imageDate,"TRAIN",imageDate.new4,"TEST",sep="")

finaling4 <- predict(xvars4, svm.fit, type="raw",
                     index=1, na.rm=TRUE, progress="text")
levels(finaling4)

writeRaster(finaling4, filename=filename14, format="GTiff", overwrite=TRUE)


##YEAR 0

source("multi_loader.R")
new.data0 <- new.mat5[sample(nrow(new.mat5),nrow(new.mat5)*data.ratio),]
new.test_x0 <- new.data0[ ,obsValues]
new.test_y0 <- new.data0[ ,classValues]

svm.predict0 <- predict(svm.fit, newdata0 = new.test_x0)
cf10 <- confusionMatrix(svm.predict0 , new.test_y0)
##This is the one that has worked
cf10 <- table(svm.predict0 , new.test_y0)

print(cf10)



# predict the final image and output it to a file
method_name0 <- "SVM"
method_name_parsed0 <- gsub ('([[:punct:]])|\\s+','_', method_name0)
filename10 <- paste(outputFolder, "/multi_",method_name_parsed0,
                    imageDate,"TRAIN",imageDate.new5,"TEST",sep="")

finaling0 <- predict(xvars5, svm.fit, type="raw",
                     index=1, na.rm=TRUE, progress="text")
levels(finaling0)

writeRaster(finaling0, filename=filename10, format="GTiff", overwrite=TRUE)





