setwd("D:/Final/171073/outputs")
r1 <- '01Apr98.tif'
rr1 <- raster(r1)
F171073D01Apr98 <- extract(rr1, ss, fun=sum, sp=TRUE) 
write.table(F171073D01Apr98, "c:/F171073D01Apr98.txt", sep="\t")

r2 <- '04Apr02.tif'
rr2 <- raster(r2)
F171073D04Apr02 <- extract(rr2, ss, fun=sum, sp=TRUE) 
write.table(F171073D04Apr02, "c:/F171073D04Apr02.txt", sep="\t")

r3 <- '04Apr99.tif'
rr3 <- raster(r3)
F171073D04Apr99 <- extract(rr3, ss, fun=sum, sp=TRUE) 
write.table(F171073D004Apr99, "c:/F171073D04Apr99.txt", sep="\t")

r4 <- '08Jan97.tif'
rr4 <- raster(r4)
F171073D08Jan97 <- extract(rr4, ss, fun=sum, sp=TRUE) 
write.table(F171073D08Jan97, "c:/F171073D08Jan97.txt", sep="\t")
save.image("C:/Users/20593368/Desktop/2017/Paper 2 Final Analysis/F171073.RData")
rm(r1)
rm(rr1)
rm(F171073D01Apr98)

rm(r2)
rm(rr2)
rm(F171073D04Apr02)

rm(r3)
rm(rr3)
rm(F171073D04Apr99)

rm(r4)
rm(rr4)
rm(F171073D08Jan97)