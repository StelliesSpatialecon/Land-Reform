setwd("C:/Users/20593368/Desktop/171073")
require (rgdal)
require (raster)
require (caret)

shapefileFolder <- "inputs/shapefiles"
shapefileName <- "171073"
bandsFolder <- "inputs/layers_08_Jan_1997"
imageDate <- substr(bandsFolder, 15, 26)
bandsPattern <- ".tif$"
outputFolder <- "outputs"

##Classification Classes
obsValues <- 6:11
classValues <- 12

##Read Shapefile
sdata <- readOGR(dsn=shapefileFolder, layer=shapefileName)
# 
##Load Bands
bandnames <- list.files(bandsFolder)
rlist <- list.files(bandsFolder, full.names=TRUE)
xvars <- stack(rlist)

names <- c("crp", "frs")


tmp <- extract (xvars, sdata)

mat = c()
for (i in 1:length(tmp)) {
  tmp_b <- cbind(sdata@data[i, ],
                 as.data.frame(tmp[i]),
                 row.names = NULL)
  tmp_b <- droplevels (tmp_b)
  #name <- levels (tmp_b$Classname)
  mat <- rbind(mat, tmp_b)
  rm (tmp_b, name)
}

variables.keep <- c('classValues', 'obsValues', 'mat','xvars', 'imageDate', 'outputFolder','start.time')
rm(list= ls()[!(ls() %in% variables.keep )])



