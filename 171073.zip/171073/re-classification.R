setwd("D:/Final/171073/outputs1")
library(raster)
str_name<-'multi_SVM08_Jan_1997TRAIN08_Jan_1997TEST.tif' 
imported_raster=raster(str_name)
imported_raster[imported_raster <= 1.2] = 1
imported_raster[imported_raster > 1.2] = 0
plot(imported_raster)
writeRaster(imported_raster, "D:/Final/171073/outputs/08Jan97", format = "GTiff")

str_name1<-'multi_SVM08_Jan_1997TRAIN04_Apr_2002TEST.tif' 
imported_raster1=raster(str_name1)
imported_raster1[imported_raster1 <= 1.2] = 1
imported_raster1[imported_raster1 > 1.2] = 0
plot(imported_raster1)
writeRaster(imported_raster1, "D:/Final/171073/outputs/04Apr02", format = "GTiff")

str_name2<-'multi_SVM08_Jan_1997TRAIN04_Apr_1999TEST.tif' 
imported_raster2=raster(str_name2)
imported_raster2[imported_raster2 <= 1.2] = 1
imported_raster2[imported_raster2 > 1.2] = 0
plot(imported_raster2)
writeRaster(imported_raster2, "D:/Final/171073/outputs/04Apr99", format = "GTiff")

str_name3<-'multi_SVM08_Jan_1997TRAIN01_Apr_1998TEST.tif' 
imported_raster3=raster(str_name3)
imported_raster3[imported_raster3 <= 1.2] = 1
imported_raster3[imported_raster3 > 1.2] = 0
plot(imported_raster3)
writeRaster(imported_raster3, "D:/Final/171073/outputs/01Apr98", format = "GTiff")