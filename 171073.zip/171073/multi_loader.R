setwd("C:/Users/20593368/Desktop/171073")
require (rgdal)
require (raster)
require (caret)


###Multi-Loader
shapefileFolder <- "inputs/shapefiles"
shapefileName <- "171073"
bandsFolder <- "inputs/layers_01_Apr_1998"
imageDate.new <- substr(bandsFolder,15,26)
bandsPattern <- ".tif$"
outputFolder <- "outputs"

##Classification Classes
obsValues <- 6:11
classValues <- 12

##Read Shapefile
sdata <- readOGR(dsn=shapefileFolder, layer=shapefileName)
# 
##Load Bands
bandnames <- list.files(bandsFolder)
rlist <- list.files(bandsFolder, full.names=TRUE)
xvars <- stack(rlist)

names <- c("crp", "frs")

tmp <- extract(xvars,sdata)


new.mat = c()
for (i in 1:length(tmp)) {
  tmp_b <- cbind(sdata@data[i, ],
                 as.data.frame(tmp [i]),
                 row.names = NULL)
  tmp_b <- droplevels(tmp_b)
  name <- levels(tmp_b$Classname)
  #if(!(name %in% names)) next
  new.mat <- rbind(new.mat, tmp_b)
}


###Multi-Loader
shapefileFolder <- "inputs/shapefiles"
shapefileName <- "171073"
bandsFolder1 <- "inputs/layers_04_Apr_1999"
imageDate.new1 <- substr(bandsFolder1,15,26)
bandsPattern <- ".tif$"
outputFolder <- "outputs"

##Classification Classes
obsValues <- 6:11
classValues <- 12

##Read Shapefile
sdata <- readOGR(dsn=shapefileFolder, layer=shapefileName)
# 
##Load Bands
bandnames1 <- list.files(bandsFolder1)
rlist1 <- list.files(bandsFolder1, full.names=TRUE)
xvars1 <- stack(rlist1)

names <- c("crp", "frs")

tmp1 <- extract(xvars1,sdata)


new.mat1 = c()
for (i in 1:length(tmp1)) {
  tmp_b1 <- cbind(sdata@data[i, ],
                  as.data.frame(tmp1 [i]),
                  row.names = NULL)
  tmp_b1 <- droplevels(tmp_b1)
  name1 <- levels(tmp_b$Classname)
  #if(!(name %in% names)) next
  new.mat1 <- rbind(new.mat1, tmp_b1)
}


###Multi-Loader
shapefileFolder <- "inputs/shapefiles"
shapefileName <- "171073"
bandsFolder2 <- "inputs/layers_11_Jan_2001"
imageDate.new2 <- substr(bandsFolder2,15,26)
bandsPattern <- ".tif$"
outputFolder <- "outputs"

##Classification Classes
obsValues <- 6:11
classValues <- 12

##Read Shapefile
sdata <- readOGR(dsn=shapefileFolder, layer=shapefileName)
# 
##Load Bands
bandnames2 <- list.files(bandsFolder2)
rlist2 <- list.files(bandsFolder2, full.names=TRUE)
xvars2 <- stack(rlist2)

names <- c("crp", "frs")

tmp2 <- extract(xvars2,sdata)


new.mat2 = c()
for (i in 1:length(tmp2)) {
  tmp_b2 <- cbind(sdata@data[i, ],
                  as.data.frame(tmp2 [i]),
                  row.names = NULL)
  tmp_b2 <- droplevels(tmp_b2)
  name2 <- levels(tmp_b2$Classname)
  #if(!(name %in% names)) next
  new.mat2 <- rbind(new.mat2, tmp_b2)
}


###Multi-Loader
shapefileFolder <- "inputs/shapefiles"
shapefileName <- "171073"
bandsFolder3 <- "inputs/layers_04_Apr_2002"
imageDate.new3 <- substr(bandsFolder3,15,26)
bandsPattern <- ".tif$"
outputFolder <- "outputs"

##Classification Classes
obsValues <- 6:11
classValues <- 12

##Read Shapefile
sdata <- readOGR(dsn=shapefileFolder, layer=shapefileName)
# 
##Load Bands
bandnames3 <- list.files(bandsFolder3)
rlist3 <- list.files(bandsFolder, full.names=TRUE)
xvars3 <- stack(rlist3)

names <- c("crp", "frs")

tmp3 <- extract(xvars3,sdata)


new.mat3 = c()
for (i in 1:length(tmp3)) {
  tmp_b3 <- cbind(sdata@data[i, ],
                  as.data.frame(tmp3 [i]),
                  row.names = NULL)
  tmp_b3 <- droplevels(tmp_b3)
  name3 <- levels(tmp_b$Classname)
  #if(!(name %in% names)) next
  new.mat3 <- rbind(new.mat3, tmp_b3)
}


###Multi-Loader
shapefileFolder <- "inputs/shapefiles"
shapefileName <- "171073"
bandsFolder4 <- "inputs/layers_07_Apr_2003"
imageDate.new4 <- substr(bandsFolder4,15,26)
bandsPattern <- ".tif$"
outputFolder <- "outputs"

##Classification Classes
obsValues <- 6:11
classValues <- 12

##Read Shapefile
sdata <- readOGR(dsn=shapefileFolder, layer=shapefileName)
# 
##Load Bands
bandnames4 <- list.files(bandsFolder4)
rlist4 <- list.files(bandsFolder4, full.names=TRUE)
xvars4 <- stack(rlist4)

names <- c("crp", "frs")

tmp4 <- extract(xvars4,sdata)


new.mat4 = c()
for (i in 1:length(tmp4)) {
  tmp_b4 <- cbind(sdata@data[i, ],
                  as.data.frame(tmp4 [i]),
                  row.names = NULL)
  tmp_b4 <- droplevels(tmp_b4)
  name4 <- levels(tmp_b$Classname)
  #if(!(name %in% names)) next
  new.mat4 <- rbind(new.mat4, tmp_b4)
}


###Multi-Loader
shapefileFolder <- "inputs/shapefiles"
shapefileName <- "171073"
bandsFolder5 <- "inputs/layers_08_Jan_1997"
imageDate.new5 <- substr(bandsFolder5,15,26)
bandsPattern <- ".tif$"
outputFolder <- "outputs"

##Classification Classes
obsValues <- 6:11
classValues <- 12

##Read Shapefile
sdata <- readOGR(dsn=shapefileFolder, layer=shapefileName)
# 
##Load Bands
bandnames5 <- list.files(bandsFolder5)
rlist5 <- list.files(bandsFolder5, full.names=TRUE)
xvars5 <- stack(rlist5)

names <- c("crp", "frs")

tmp5 <- extract(xvars5,sdata)


new.mat5 = c()
for (i in 1:length(tmp5)) {
  tmp_b5 <- cbind(sdata@data[i, ],
                  as.data.frame(tmp5 [i]),
                  row.names = NULL)
  tmp_b5 <- droplevels(tmp_b5)
  name5 <- levels(tmp_b5$Classname)
  #if(!(name %in% names)) next
  new.mat5 <- rbind(new.mat5, tmp_b5)
}

